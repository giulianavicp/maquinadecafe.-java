
package fatec.lacos;


public class Cafe {
    public int tipocafes(int num)  {
        
        if (num == 1) {
            return 1;
        } else if (num == 2) {
            return 2;
        } else if (num == 3) {
            return 3;
        } else if (num == 4) {
            return 4;
        } else if (num == 5) {
            return 5;
        } else {
            return 6;
        }
       
        return 0;
    }

    public int preparar(int num){
        if(num ==1){
            return 1;
        { else {
            return 2;
        }
    } 
 }